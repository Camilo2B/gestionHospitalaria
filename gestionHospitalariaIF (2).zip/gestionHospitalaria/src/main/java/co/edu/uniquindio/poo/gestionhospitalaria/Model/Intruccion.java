package co.edu.uniquindio.poo.gestionhospitalaria.Model;

public enum Intruccion {
    ORAL,
    INTRAVENOSA,
    NASAL,
}