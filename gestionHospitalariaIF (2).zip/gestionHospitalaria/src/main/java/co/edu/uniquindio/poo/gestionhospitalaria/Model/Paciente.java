package co.edu.uniquindio.poo.gestionhospitalaria.Model;

public class Paciente extends Persona{

    public Paciente(String nombre, String cedula, int edad) {
        super(nombre, edad, cedula);
    }
}