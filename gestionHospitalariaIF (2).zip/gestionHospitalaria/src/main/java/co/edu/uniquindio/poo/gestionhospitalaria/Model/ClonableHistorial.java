package co.edu.uniquindio.poo.gestionhospitalaria.Model;

public interface ClonableHistorial extends Cloneable{

    HistorialMedico Clone();
    
}